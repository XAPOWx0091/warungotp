# MAULANA NOKOS — UI Preview

Responsive blue-futuristic SaaS interface prototype (static HTML/CSS/JS). This is a UI preview, **not a live OTP ordering or payment service**.

## Open
Open `index.html` in a browser. No build step is needed for the UI preview.

## What's included
- Premium landing page, responsive layout, mobile sizing
- Login/register visual screens
- Dashboard navigation: overview, order, active orders, history, deposit, deposit history, profile
- Explicit demo-mode / provider-not-connected states (no fabricated stock, prices, user stats, orders, or balances)

## Not connected yet
- Authentication/database (MongoDB)
- ASCNOOTP API (API documentation and credentials required; do not guess endpoint names)
- Payment gateway / QRIS
- Telegram SC bot notifier (existing script and its DB/config need to be audited before connecting)
- Backend admin panel, transaction ledger, real order/deposit lifecycle

## Production implementation plan
1. Audit the current Telegram SC code and existing MongoDB schema.
2. Verify official ASCNOOTP documentation, base URL, endpoints, request/response schema, authentication, and cancellation/refund rules.
3. Implement Next.js + TypeScript server routes/provider adapter, auth, atomic ledger transactions and idempotency.
4. Wire payment callbacks/polling, Telegram notifier module, admin roles, and actual live frontend data.
5. Test order/deposit/refund concurrency, provider errors/timeouts, build, and deploy to VPS.

Do not add real provider keys or Telegram bot token to frontend files. Keep them server-side in environment variables.
